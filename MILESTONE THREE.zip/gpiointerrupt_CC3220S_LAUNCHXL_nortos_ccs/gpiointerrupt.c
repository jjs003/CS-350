/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* Keeps track of the current position in ongoing morse code sequence */
unsigned int messageCounter = 0;

/* Flag to keep track of when a button has been pressed */
volatile unsigned int buttonPressed = 0;

/* Timer flag */
volatile unsigned int TimerFlag = 0;

/* Morse code message choices with variable to track current message set to SOS by default */
enum MC_Messages {SOS, OK}
Current_Msg = SOS;

/* LED states */
typedef enum {RED, GREEN, OFF} LED_States;

/* Variable for tracking current LED state */
LED_States LED_State;

/* 'SOS' Morse code message */
LED_States SOS_Message[] = {
   /* S */
   RED, OFF,                                      // Dot
   RED, OFF,                                      // Dot
   RED, OFF, OFF, OFF,                            // Dot, pause between characters

   /* O */
   GREEN, GREEN, GREEN, OFF,                      // Dash
   GREEN, GREEN, GREEN, OFF,                      // Dash
   GREEN, GREEN, GREEN, OFF, OFF, OFF,            // Dash, pause between characters

   /* S */
   RED, OFF,                                      // Dot
   RED, OFF,                                      // Dot
   RED, OFF, OFF, OFF, OFF, OFF, OFF, OFF         // Dot, pause between words
};

const unsigned int SOS_MESSAGE_LENGTH = (sizeof(SOS_Message) / sizeof(SOS_Message[0]));

/* 'OK' Morse code message */
LED_States OK_Message[] = {
   /* O */
   GREEN, GREEN, GREEN, OFF,                                // Dash
   GREEN, GREEN, GREEN, OFF,                                // Dash
   GREEN, GREEN, GREEN, OFF, OFF, OFF,                      // Dash, pause between characters

   /* K */
   GREEN, GREEN, GREEN, OFF,                                // Dash
   RED, OFF,                                                // Dot
   GREEN, GREEN, GREEN, OFF, OFF, OFF, OFF, OFF, OFF, OFF   // Dash, pause between words
};

const unsigned int OK_MESSAGE_LENGTH = (sizeof(OK_Message) / sizeof(OK_Message[0]));

/*
 *  ======== processLEDState ========
 *  Function for the LEDs to represent a dot, dash, or break.
 */
void processLEDState() {
    switch(LED_State) {
        case RED:   // Dot
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            break;
        case GREEN: // Dash
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            break;
        case OFF:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            break;
        default:
            break;
    }
}


/* Enum representing each possible state in the state machine
 * Initial state is set to MC_s0 */
enum MC_States {MC_s0, MC_s1, MC_s2}
MC_State = MC_s0;

/*
 *  ======== TickFct_MorseCode ========
 *  Tick function to handle each tick of the state machine.
 */
void TickFct_MorseCode() {
    /* State Machine to handle the output of SOS messages and the transition between each message*/
    /* Transitions*/
    switch(MC_State) {
        /* SOS message (default state)*/
        case MC_s0:
            /* Check if message has been completed*/
            if (messageCounter >= SOS_MESSAGE_LENGTH) {
                MC_State = MC_s1;
            }
            /* Message was not completed, stay in the current state*/
            else if (!(messageCounter >= SOS_MESSAGE_LENGTH)) {
                MC_State = MC_s0;
            }
            break;

        /* Message has been completed, decide next message state*/
        case MC_s1:
            /* Next message is SOS, proceed to state s0*/
            if (Current_Msg == SOS) {
                MC_State = MC_s0;
            }
            else if (Current_Msg != SOS) {
                MC_State = MC_s2;
            }
            break;

        /* OK message*/
        case MC_s2:
            /* Check if message has been completed*/
            if (messageCounter >= OK_MESSAGE_LENGTH) {
                MC_State = MC_s1;
            }
            /* Message was not completed, stay in the current state*/
            else if (!(messageCounter >= OK_MESSAGE_LENGTH)) {
                MC_State = MC_s2;
            }
            break;

        default:
            MC_State = MC_s0;
            break;
    }

    /* State actions*/
    switch(MC_State) {

        /* SOS message (default state)
         * Process current LED state and increment message counter */
        case MC_s0:
            /* Set current LED state to be processed */
            LED_State = SOS_Message[messageCounter];
            processLEDState();
            messageCounter++;
            break;

        /* Decide new message state and then reset message counter and button pressed flag */
        case MC_s1:
            /* Button was pressed, proceed to new message state*/
            if (buttonPressed) {
                if (Current_Msg == SOS) {
                    Current_Msg = OK;
                }
                else if (Current_Msg != SOS) {
                    Current_Msg = SOS;
                }
            }
            /* Button was not pressed, remain in current message state*/
            else if (!buttonPressed) {
                Current_Msg = Current_Msg;
            }

            /* Reset message counter and button pressed flag */
            messageCounter = 0;
            buttonPressed = 0;
            break;

            /* OK message
             * Process current LED state and increment message counter */
        case MC_s2:
            /* Set current LED state to be processed */
            LED_State = OK_Message[messageCounter];
            processLEDState();
            messageCounter++;
            break;

        default:
            break;
    }
}

/*
 *  ======== gpioButtonCallback ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0 and CONFIG_GPIO_BUTTON_1.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonCallback(uint_least8_t index)
{
    /* Set button pressed flag */
    buttonPressed = 1;
}

/*
 *  ======== timerCallback ========
 *  Callback function for the timer interrupt.
 */
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    /* Set timer flag */
    TimerFlag = 1;
}

/*
 *  ======== timerInit ========
 *  Initialization function for the timer interrupt on timer0.
 */
void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
        /* Failed to initialize timer */
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /*Failed to start timer */
        while (1) {}
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions for GPIO and timer */
    GPIO_init();
    initTimer();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Initialize LEDs to OFF */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonCallback);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonCallback);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    /* State machine loop */
    while (1) {
        TickFct_MorseCode();    // Tick the MorseCode SM
        while (!TimerFlag) {}   // Wait for the timer period
        TimerFlag = 0;          // Reset timer flag
    }
}
